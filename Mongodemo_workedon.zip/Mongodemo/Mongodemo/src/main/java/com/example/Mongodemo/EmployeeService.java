package com.example.Mongodemo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/emp")
public class EmployeeService
{
	@Autowired
	Dbservice service;
	
	
	@PostMapping("/inser")
	public String insert(@RequestBody Employee e)
	{
		service.save(e);
		return "Success";
	}
	
	@GetMapping("/findbyId/{id}")
	public Optional<Employee> find(@PathVariable("id") Long id)
	{
		return service.findById(id);
	}
	
	@PostMapping("/update/{id}")
	public String update(@PathVariable("id") Long id,@RequestBody Employee e)
	{
		if(service.existsById(id))
    	{
    		service.save(e);
    		return "Success";
    	}
		else
			return "Failure";
		
	}
	
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable("id") Long id)
	{
		if(service.existsById(id))
    	{
    		service.deleteById(id);
    		return "Success";
    	}
		else
			return "Failure";
	}
	
	@GetMapping("/getByName/{name}")
	public String getName(@PathVariable("name") String n )
	{
		return service.findByName(n);
	}
	
	@GetMapping("/getAll")
	public  List<Employee> getName()
	{
		return service.findAll();
	}
	
	 
}
