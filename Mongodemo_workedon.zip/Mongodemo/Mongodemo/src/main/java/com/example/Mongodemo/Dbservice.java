package com.example.Mongodemo;

import org.springframework.data.mongodb.repository.MongoRepository;



public interface Dbservice extends MongoRepository<Employee,Long> 
{

	String findByName(String n);
	
}
